---
name: Typos and doc fixes
about: Typos and doc fixes
title: ''
labels: documentation
assignees: ''
---

## 📚 Documentation

For typos and doc fixes, please go ahead and:

1. Create an issue.
1. Fix the typo.
1. Submit a PR.

For very simple fixes, you can submit a PR without a linked issue.

Thanks!
