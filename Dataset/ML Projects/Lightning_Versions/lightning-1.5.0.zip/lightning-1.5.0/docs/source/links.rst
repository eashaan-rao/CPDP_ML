.. _PyTorchJob: https://www.kubeflow.org/docs/components/training/pytorch/
.. _Kubeflow: https://www.kubeflow.org
