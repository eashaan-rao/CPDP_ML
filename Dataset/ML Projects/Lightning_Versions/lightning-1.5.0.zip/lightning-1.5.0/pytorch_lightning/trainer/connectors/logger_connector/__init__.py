from pytorch_lightning.trainer.connectors.logger_connector.logger_connector import LoggerConnector  # noqa: F401
