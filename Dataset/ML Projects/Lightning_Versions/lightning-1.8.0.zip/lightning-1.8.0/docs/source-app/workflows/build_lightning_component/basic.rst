#############################
Develop a Lightning Component
#############################

**Audience:** Users who want to develop a Lightning Component.

----

.. include:: from_scratch_component_content.rst
