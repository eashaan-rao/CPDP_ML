#########################################
Add a web UI with React.js (intermediate)
#########################################
**Audience:** Anyone who wants to add a web user interface (UI) written in react to their app.

**pre-requisites:** You already have a React app connected with a Lightning app.

----

**********************
Develop your react app
**********************
Every time you make a change to your React.js app, you must call `yarn build` to apply the changes (this is a React.js thing):

.. code:: bash

    # if you're lost, the right folder has a package.json in it
    cd folder-with-ui-folder/ui
    yarn build

This can get very repetitive, there is a "hot reload" command that you can enable with:

.. code:: bash

    # TODO

There are many other tricks that React.js developers use to improve their development speed.
