:orphan:

######################
Run on a private cloud
######################
**Audience:** Users looking to run Lightning apps on their private cloud accounts.

----

******************************
Run on a private cloud account
******************************
For enterprise, startups and University use-cases, Lightning AI can run on your own AWS account (with your own credentials), with all the infrastructure fully managed by us.
To enable this, contact our support team to get started:

onprem@lightning.ai

----


***********
Run on-prem
***********
For enterprise-level security with full control of the Lightning AI system on your own on-prem cluster, contact our support team to get started:

onprem@lightning.ai
