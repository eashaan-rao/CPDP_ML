#############################
Develop a Lightning Component
#############################

A Lightning App (App) is a collection of components interacting together. Learn how to build a Lightning Component (Component) in this section.

----

.. include:: index_content.rst
