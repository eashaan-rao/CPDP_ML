#######################
Develop a Lightning App
#######################

A Lightning App (App) is a collection of components interacting together. Learn how to develop a basic App template.

----

.. include:: index_content.rst
