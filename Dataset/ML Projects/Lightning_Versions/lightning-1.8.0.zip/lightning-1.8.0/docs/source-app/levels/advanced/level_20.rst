#######################################
Level 20: Enable dynamic LightningWorks
#######################################

**Audience:** Users who want to create/run/stop multiple LightningWorks not defined at app instantiation.

**Prereqs:** Level 16+

----

.. include:: ../../core_api/lightning_app/dynamic_work_content.rst
