###########################################
Level 8: Build a Lightning App from Scratch
###########################################
**Audience:** Users who want to build an Lightning App from scratch

**Prereqs:** You must have finished the `Basic levels <https://lightning.ai/lightning-docs/levels/basic/>`_.

----

.. include:: ../../workflows/build_lightning_app/from_scratch_content.rst
