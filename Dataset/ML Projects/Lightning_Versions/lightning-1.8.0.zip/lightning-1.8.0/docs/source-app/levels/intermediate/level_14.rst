########################################
Level 14: Share files between components
########################################
**Audience:** Users who are moving large files such as artifacts or datasets.

**Prereqs:** Level 8+

----

.. include:: ../../glossary/storage/drive_content.rst
