######################
Level 12: Flow vs Work
######################
**Audience:** Users who need to do non trivial workloads in their apps.

**Prereqs:** Level 8+

----

.. include:: ../../workflows/build_lightning_component/from_scratch_component_content.rst
