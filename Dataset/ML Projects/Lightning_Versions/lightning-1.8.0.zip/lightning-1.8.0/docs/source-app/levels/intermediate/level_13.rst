####################################################
Level 13: Communication between Lightning Components
####################################################
**Audience:** Users who have multiple LightningWorks communicating with LightningFlows.

**Prereqs:** Level 8+

----

.. include:: ../../core_api/lightning_app/communication_content.rst
