############################
Lightning Apps in 15 minutes
############################

**Required background:** Basic Python familiarity.

**Goal:** Guide you to develop your first Lightning App or use an existing App from the `Apps Gallery <https://lightning.ai/apps>`_.

.. join_slack::
   :align: left

----

.. include:: go_beyond_training_content.rst
