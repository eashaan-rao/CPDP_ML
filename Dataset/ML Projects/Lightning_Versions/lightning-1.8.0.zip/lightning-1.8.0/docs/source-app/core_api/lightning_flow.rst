.. _lightning_flow:

#############
LightningFlow
#############

.. autoclass:: lightning_app.core.flow.LightningFlow
    :exclude-members: _attach_backend, _exit, _is_state_attribute, set_state
