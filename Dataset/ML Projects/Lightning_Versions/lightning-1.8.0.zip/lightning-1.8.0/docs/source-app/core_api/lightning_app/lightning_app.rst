:orphan:

.. _lightning_app:

############
LightningApp
############


.. autoclass:: lightning_app.core.app.LightningApp
    :exclude-members: _run, connect, get_component_by_name, maybe_apply_changes, set_state
    :noindex:
