:orphan:

.. _lightning_work:

#############
LightningWork
#############

.. autoclass:: lightning_app.core.work.LightningWork
    :exclude-members: _aggregate_status_timeout, _is_state_attribute, _is_state_attribute, set_state
    :noindex:
