
.. _fileserver_example:

#####################
Develop a File Server
#####################

**Prerequisite**: Reach :ref:`level 16+ <intermediate_level>` and read the :ref:`Drive article <drive_storage>`.

----

.. include:: file_server_content.rst
