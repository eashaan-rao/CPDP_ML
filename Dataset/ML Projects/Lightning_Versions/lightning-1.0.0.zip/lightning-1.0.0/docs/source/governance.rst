.. _governance:

PyTorch Lightning Governance | Persons of interest
==================================================

Leads
-----
- William Falcon (`williamFalcon <https://github.com/williamFalcon>`_) (Lightning founder)
- Jirka Borovec (`Borda <https://github.com/Borda>`_)
- Ethan Harris (`ethanwharris <https://github.com/ethanwharris>`_) (Torchbearer founder)
- Matthew Painter (`MattPainter01 <https://github.com/MattPainter01>`_) (Torchbearer founder)
- Justus Schock (`justusschock <https://github.com/justusschock>`_) (Former Core Member PyTorch Ignite)

Core Maintainers
----------------
- Nic Eggert (`neggert <https://github.com/neggert>`_)
- Jeff Ling (`jeffling <https://github.com/jeffling>`_)
- Jeremy Jordan (`jeremyjordan <https://github.com/jeremyjordan>`_)
- Tullie Murrell (`tullie <https://github.com/tullie>`_)
- Adrian Wälchli (`awaelchli <https://github.com/awaelchli>`_)
- Nicki Skafte (`skaftenicki <https://github.com/SkafteNicki>`_)
- Peter Yu (`yukw777 <https://github.com/yukw777>`_)
- Rohit Gupta (`rohitgr7 <https://github.com/rohitgr7>`_)
- Lezwon Castelino (`lezwon <https://github.com/lezwon>`_)
- Jeff Yang (`ydcjeff <https://github.com/ydcjeff>`_)
- Roger Shieh (`s-rog <https://github.com/s-rog>`_)
