jax.image package
=================

.. currentmodule:: jax.image

.. automodule:: jax.image


Image manipulation functions
----------------------------

.. autosummary::
  :toctree: _autosummary

    resize

