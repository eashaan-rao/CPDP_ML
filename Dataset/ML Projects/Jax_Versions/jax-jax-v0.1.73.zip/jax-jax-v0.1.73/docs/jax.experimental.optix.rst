jax.experimental.optix module
==============================

.. automodule:: jax.experimental.optix
    :members:
    :undoc-members:
    :show-inheritance:
