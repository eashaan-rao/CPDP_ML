jax.experimental.host_callback module
=====================================


.. automodule:: jax.experimental.host_callback

API
---

.. autofunction:: id_tap
.. autofunction:: id_print
.. autofunction:: outfeed_receiver
.. autoexception:: TapFunctionException



