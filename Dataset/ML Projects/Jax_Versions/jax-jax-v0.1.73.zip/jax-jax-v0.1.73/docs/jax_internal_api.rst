Internal APIs
=============

core
-----

.. currentmodule:: jax.core
.. automodule:: jax.core

.. autosummary::
  :toctree: _autosummary

   Jaxpr
   TypedJaxpr
