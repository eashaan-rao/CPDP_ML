This directory contains examples of using the jax2tf converter to produce
models that can be used with TensorFlow.js. Note that this is still highly
experimental.
