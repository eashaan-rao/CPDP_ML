Design Notes
============

.. toctree::
   :maxdepth: 1

   custom_derivatives
   jax_versioning
   omnistaging
   prng
   type_promotion
   sequencing_effects
