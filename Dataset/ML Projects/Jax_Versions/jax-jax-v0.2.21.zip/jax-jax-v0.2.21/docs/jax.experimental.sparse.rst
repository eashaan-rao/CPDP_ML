jax.experimental.sparse module
==============================

.. automodule:: jax.experimental.sparse

API
---

.. autoclass:: BCOO
.. autofunction:: sparsify
