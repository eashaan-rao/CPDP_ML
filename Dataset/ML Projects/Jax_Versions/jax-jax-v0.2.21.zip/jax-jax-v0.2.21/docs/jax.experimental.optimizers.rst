jax.experimental.optimizers module
==================================

.. automodule:: jax.experimental.optimizers
    :members:
    :undoc-members:
    :show-inheritance:
