jax.experimental.ann module
===========================

.. automodule:: jax.experimental.ann

API
---

.. autofunction:: approx_max_k
.. autofunction:: approx_min_k
