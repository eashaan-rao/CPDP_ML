jax.example_libraries package
=============================

.. toctree::
    :maxdepth: 1

    jax.example_libraries.optimizers
    jax.example_libraries.stax

.. automodule:: jax.example_libraries
