jax.example_libraries.stax module
=================================

.. automodule:: jax.example_libraries.stax
    :members:
    :undoc-members:
    :show-inheritance:
