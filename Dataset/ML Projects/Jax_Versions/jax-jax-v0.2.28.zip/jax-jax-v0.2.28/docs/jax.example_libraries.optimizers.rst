jax.example_libraries.optimizers module
=======================================

.. automodule:: jax.example_libraries.optimizers
    :members:
    :undoc-members:
    :show-inheritance:
