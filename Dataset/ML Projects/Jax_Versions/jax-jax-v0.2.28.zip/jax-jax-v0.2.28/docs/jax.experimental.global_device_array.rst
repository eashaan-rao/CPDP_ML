jax.experimental.global_device_array module
===========================================

.. automodule:: jax.experimental.global_device_array

API
---

.. autoclass:: GlobalDeviceArray
    :members:
.. autoclass:: Shard