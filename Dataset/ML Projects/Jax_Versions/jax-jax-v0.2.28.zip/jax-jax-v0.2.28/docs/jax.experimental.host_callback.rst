jax.experimental.host_callback module
=====================================


.. automodule:: jax.experimental.host_callback

API
---

.. autofunction:: id_tap
.. autofunction:: id_print
.. autofunction:: call
.. autofunction:: barrier_wait
.. autoexception:: CallbackException



