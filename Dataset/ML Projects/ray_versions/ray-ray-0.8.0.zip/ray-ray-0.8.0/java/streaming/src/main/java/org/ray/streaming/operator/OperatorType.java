package org.ray.streaming.operator;


public enum OperatorType {
  MASTER,
  SOURCE,
  ONE_INPUT,
  TWO_INPUT,
}
