package org.ray.api.function;

/**
 * Interface of all `RayFuncVoidX` classes.
 */
public interface RayFuncVoid extends RayFunc {

}
