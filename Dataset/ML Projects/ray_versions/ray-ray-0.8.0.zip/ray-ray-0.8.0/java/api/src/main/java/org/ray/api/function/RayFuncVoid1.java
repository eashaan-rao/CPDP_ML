// generated automatically, do not modify.

package org.ray.api.function;

/**
 * Functional interface for a remote function that has 1 parameter.
 */
@FunctionalInterface
public interface RayFuncVoid1<T0> extends RayFuncVoid {

  void apply(T0 t0) throws Exception;
}
