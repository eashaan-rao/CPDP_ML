// generated automatically, do not modify.

package org.ray.api.function;

/**
 * Functional interface for a remote function that has 0 parameter.
 */
@FunctionalInterface
public interface RayFunc0<R> extends RayFunc {

  R apply() throws Exception;
}
