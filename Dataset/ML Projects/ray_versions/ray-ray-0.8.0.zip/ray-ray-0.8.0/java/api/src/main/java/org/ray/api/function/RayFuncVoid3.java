// generated automatically, do not modify.

package org.ray.api.function;

/**
 * Functional interface for a remote function that has 3 parameters.
 */
@FunctionalInterface
public interface RayFuncVoid3<T0, T1, T2> extends RayFuncVoid {

  void apply(T0 t0, T1 t1, T2 t2) throws Exception;
}
