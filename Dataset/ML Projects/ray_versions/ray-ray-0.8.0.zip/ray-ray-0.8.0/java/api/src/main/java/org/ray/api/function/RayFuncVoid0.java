// generated automatically, do not modify.

package org.ray.api.function;

/**
 * Functional interface for a remote function that has 0 parameter.
 */
@FunctionalInterface
public interface RayFuncVoid0 extends RayFuncVoid {

  void apply() throws Exception;
}
