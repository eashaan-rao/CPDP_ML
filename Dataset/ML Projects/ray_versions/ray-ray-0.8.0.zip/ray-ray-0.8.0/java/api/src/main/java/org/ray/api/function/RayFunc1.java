// generated automatically, do not modify.

package org.ray.api.function;

/**
 * Functional interface for a remote function that has 1 parameter.
 */
@FunctionalInterface
public interface RayFunc1<T0, R> extends RayFunc {

  R apply(T0 t0) throws Exception;
}
