---
name: Feature request
about: Suggest an idea for Ray, Tune, RLlib, etc.
title: ''
labels: enhancement
assignees: ''

---

<!--Please include [tune], [rllib], [autoscaler] etc. in the issue title if relevant-->

### Describe your feature request
