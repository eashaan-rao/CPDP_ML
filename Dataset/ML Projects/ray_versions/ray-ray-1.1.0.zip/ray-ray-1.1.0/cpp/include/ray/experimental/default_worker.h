#pragma once

namespace ray {
namespace api {

int default_worker_main(int argc, char **argv);

}  // namespace api
}  // namespace ray
