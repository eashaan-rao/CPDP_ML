:orphan:

mnist_ptl_mini
~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/mnist_ptl_mini.py
