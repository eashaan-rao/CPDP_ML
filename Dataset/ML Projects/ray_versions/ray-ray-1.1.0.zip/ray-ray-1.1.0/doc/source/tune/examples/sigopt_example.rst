:orphan:

sigopt_example
~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/sigopt_example.py
