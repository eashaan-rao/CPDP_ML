:orphan:

tf_mnist_example
~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/tf_mnist_example.py
