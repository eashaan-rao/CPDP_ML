:orphan:

ax_example
~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/ax_example.py
