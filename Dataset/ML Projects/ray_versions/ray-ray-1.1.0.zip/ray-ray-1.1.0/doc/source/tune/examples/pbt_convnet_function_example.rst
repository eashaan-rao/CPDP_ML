:orphan:

pbt_convnet_function_example
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pbt_convnet_function_example.py
