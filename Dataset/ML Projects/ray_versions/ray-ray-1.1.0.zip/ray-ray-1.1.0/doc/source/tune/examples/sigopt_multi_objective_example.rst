:orphan:

sigopt_multi_objective_example
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/sigopt_multi_objective_example.py
