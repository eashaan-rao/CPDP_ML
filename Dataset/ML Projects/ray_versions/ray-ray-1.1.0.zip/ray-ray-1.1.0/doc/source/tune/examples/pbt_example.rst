:orphan:

pbt_example
~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pbt_example.py
