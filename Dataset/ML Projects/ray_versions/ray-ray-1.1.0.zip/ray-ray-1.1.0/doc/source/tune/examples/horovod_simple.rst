:orphan:

horovod_simple
~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/horovod_simple.py