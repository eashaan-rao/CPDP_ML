:orphan:

tune_mnist_keras
~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/tune_mnist_keras.py
