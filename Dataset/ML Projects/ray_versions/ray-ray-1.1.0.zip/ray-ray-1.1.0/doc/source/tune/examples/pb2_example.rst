:orphan:

pb2_example
~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pb2_example.py