:orphan:

tune_cifar10_gluon
~~~~~~~~~~~~~~~~~~


.. literalinclude:: /../../python/ray/tune/examples/tune_cifar10_gluon.py
