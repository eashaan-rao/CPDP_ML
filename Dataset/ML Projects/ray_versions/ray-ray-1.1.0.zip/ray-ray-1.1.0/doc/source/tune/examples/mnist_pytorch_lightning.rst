:orphan:

mnist_pytorch_lightning
~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/mnist_pytorch_lightning.py
