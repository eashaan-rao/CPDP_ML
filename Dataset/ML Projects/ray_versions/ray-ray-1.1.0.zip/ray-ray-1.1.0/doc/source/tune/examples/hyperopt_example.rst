:orphan:

hyperopt_example
~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/hyperopt_example.py