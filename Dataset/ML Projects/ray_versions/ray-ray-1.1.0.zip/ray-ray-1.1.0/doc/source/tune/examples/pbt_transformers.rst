:orphan:

pbt_transformers_example
~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pbt_transformers/pbt_transformers.py
.. literalinclude:: /../../python/ray/tune/examples/pbt_transformers/utils.py