:orphan:

sigopt_prior_beliefs_example
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/sigopt_prior_beliefs_example.py
