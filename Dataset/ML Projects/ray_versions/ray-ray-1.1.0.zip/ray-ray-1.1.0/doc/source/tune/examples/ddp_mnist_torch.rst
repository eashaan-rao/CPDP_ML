:orphan:

ddp_mnist_torch
~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/ddp_mnist_torch.py
