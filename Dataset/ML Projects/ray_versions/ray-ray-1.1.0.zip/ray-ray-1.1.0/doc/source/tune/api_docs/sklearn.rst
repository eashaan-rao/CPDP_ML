.. _tune-sklearn-docs:

Scikit-Learn API  (tune.sklearn)
================================

.. _tunegridsearchcv-docs:

TuneGridSearchCV
----------------

.. autoclass:: ray.tune.sklearn.TuneGridSearchCV
	:inherited-members:

.. _tunesearchcv-docs:

TuneSearchCV
------------

.. autoclass:: ray.tune.sklearn.TuneSearchCV
	:inherited-members:
