:orphan:

hyperband_function_example
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/hyperband_function_example.py
