:orphan:

mnist_pytorch_trainable
~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/mnist_pytorch_trainable.py
