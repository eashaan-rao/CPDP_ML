:orphan:

skopt_example
~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/skopt_example.py
