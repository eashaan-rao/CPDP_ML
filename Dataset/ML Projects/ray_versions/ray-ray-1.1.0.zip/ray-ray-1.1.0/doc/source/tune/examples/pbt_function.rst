:orphan:

pbt_function
~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pbt_function.py
