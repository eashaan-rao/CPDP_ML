:orphan:

bayesopt_example
~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/bayesopt_example.py
