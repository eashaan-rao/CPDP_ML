:orphan:

xgboost_example
~~~~~~~~~~~~~~~


.. literalinclude:: /../../python/ray/tune/examples/xgboost_example.py