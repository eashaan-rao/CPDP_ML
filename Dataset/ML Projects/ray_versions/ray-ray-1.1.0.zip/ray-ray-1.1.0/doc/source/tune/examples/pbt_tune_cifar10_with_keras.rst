:orphan:

pbt_tune_cifar10_with_keras
~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/pbt_tune_cifar10_with_keras.py