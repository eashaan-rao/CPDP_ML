:orphan:

cifar10_pytorch
~~~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/cifar10_pytorch.py
