:orphan:

zoopt_example
~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/zoopt_example.py
