:orphan:

mxnet_example
~~~~~~~~~~~~~

.. literalinclude:: /../../python/ray/tune/examples/mxnet_example.py
