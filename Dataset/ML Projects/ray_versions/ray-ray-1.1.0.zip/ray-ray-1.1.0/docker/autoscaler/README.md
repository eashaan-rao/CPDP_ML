# DEPRECATED -- Please use [`rayproject/ray-ml`](https://hub.docker.com/repository/docker/rayproject/ray-ml)
## About
This image used to be the base image for the Ray autoscaler, but it has been replaced by [`rayproject/ray-ml`](https://hub.docker.com/repository/docker/rayproject/ray-ml). 
Please use that instead, *this image will be removed in the near future*.


## Tags
* [`:latest`](https://hub.docker.com/repository/docker/rayproject/autoscaler/tags?page=1&name=latest) - The most recent Ray release.
* `:1.x.x` - A specific release build. 
* [`:nightly`](https://hub.docker.com/repository/docker/rayproject/autoscaler/tags?page=1&name=nightly) - The most recent nightly build.
* `:SHA` - A specific nightly build.