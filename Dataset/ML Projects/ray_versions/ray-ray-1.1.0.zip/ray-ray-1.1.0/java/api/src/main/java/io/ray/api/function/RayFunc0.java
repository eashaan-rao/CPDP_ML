// generated automatically, do not modify.

package io.ray.api.function;

/**
 * Functional interface for a remote function that has 0 parameter.
 */
@FunctionalInterface
public interface RayFunc0<R> extends RayFuncR<R> {

  R apply() throws Exception;
}
