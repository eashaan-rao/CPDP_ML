// generated automatically, do not modify.

package io.ray.api.function;

/**
 * Functional interface for a remote function that has 1 parameter.
 */
@FunctionalInterface
public interface RayFunc1<T0, R> extends RayFuncR<R> {

  R apply(T0 t0) throws Exception;
}
