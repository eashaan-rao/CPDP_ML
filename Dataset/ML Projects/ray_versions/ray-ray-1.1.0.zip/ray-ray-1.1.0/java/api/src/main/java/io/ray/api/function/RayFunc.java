package io.ray.api.function;

import java.io.Serializable;

/**
 * Base interface of all Ray remote java functions.
 */
public interface RayFunc extends Serializable {
}
