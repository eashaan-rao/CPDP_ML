.. _random-access-dataset-api:

(Experimental) RandomAccessDataset API
======================================

.. autoclass:: ray.data.random_access_dataset.RandomAccessDataset
    :members: