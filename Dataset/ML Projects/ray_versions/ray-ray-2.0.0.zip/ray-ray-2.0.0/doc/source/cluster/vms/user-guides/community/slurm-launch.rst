:orphan:

.. _slurm-launch:

slurm-launch.py
~~~~~~~~~~~~~~~

.. literalinclude:: /cluster/doc_code/slurm-launch.py
