:orphan:

.. _slurm-basic:

slurm-basic.sh
~~~~~~~~~~~~~~

.. literalinclude:: /cluster/doc_code/slurm-basic.sh
