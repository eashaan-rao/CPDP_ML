(vm-cluster-examples)=

# Examples

:::{note}
To learn the basics of Ray on Cloud VMs, we recommend taking a look
at the {ref}`introductory guide <vm-cluster-quick-start>` first.
:::

This section presents example Ray workloads to try out on your cloud cluster.

More examples will be added in the future. Running the distributed XGBoost example below is a
great way to start experimenting with production Ray workloads in the cloud.
- {ref}`clusters-vm-ml-example`
