# Index

This section introduces the main differences in running a Ray application on your laptop vs on a Ray Cluster.
To get started, check out the [job submissions](jobs-quickstart) page.

```{toctree}
:maxdepth: '2'

job-submission/index
monitoring-and-observability
autoscaling/reference
```
