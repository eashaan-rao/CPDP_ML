:orphan:

.. _slurm-template:

slurm-template.sh
~~~~~~~~~~~~~~~~~

.. literalinclude:: /cluster/doc_code/slurm-template.sh
    :language: bash
