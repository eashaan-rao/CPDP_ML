(vm-cluster-api-references)=

# API References

The following pages provide reference documentation for using Ray Clusters on virtual machines.

```{toctree}
:caption: "Reference documentation for Ray Clusters on VMs:"
:maxdepth: '2'
:name: ray-clusters-vms-reference

ray-cluster-cli
ray-cluster-configuration
```
