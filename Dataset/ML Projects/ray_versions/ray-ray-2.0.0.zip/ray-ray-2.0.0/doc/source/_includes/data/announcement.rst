.. image:: https://ray-docs-promo.netlify.app/assets/img/data/top.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/data

.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/data/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/data
