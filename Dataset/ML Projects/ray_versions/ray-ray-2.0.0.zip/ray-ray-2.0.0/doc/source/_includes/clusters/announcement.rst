.. image:: https://ray-docs-promo.netlify.app/assets/img/clusters/top.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/clusters

.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/clusters/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/clusters
