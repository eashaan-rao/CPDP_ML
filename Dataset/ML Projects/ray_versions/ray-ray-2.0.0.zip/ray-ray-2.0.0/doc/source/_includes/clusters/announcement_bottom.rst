.. image:: https://ray-docs-promo.netlify.app/assets/img/clusters/bottom.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/clusters
