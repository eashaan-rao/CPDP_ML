You can post questions or issues or feedback through the following channels:

1. `Discussion Board`_: For **questions about Ray usage** or **feature requests**.
2. `GitHub Issues`_: For **bug reports**.
3. `Ray Slack`_: For **getting in touch** with Ray maintainers.
4. `StackOverflow`_: Use the [ray] tag **questions about Ray**.

.. _`Discussion Board`: https://discuss.ray.io/
.. _`GitHub Issues`: https://github.com/ray-project/ray/issues
.. _`Ray Slack`: https://forms.gle/9TSdDYUgxYs8SA9e8
.. _`StackOverflow`: https://stackoverflow.com/questions/tagged/ray
