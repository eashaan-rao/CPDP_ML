.. image:: https://ray-docs-promo.netlify.app/assets/img/serve/top.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/serve

.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/serve/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/serve
