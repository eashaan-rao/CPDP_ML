.. image:: https://ray-docs-promo.netlify.app/assets/img/core/bottom.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/core
