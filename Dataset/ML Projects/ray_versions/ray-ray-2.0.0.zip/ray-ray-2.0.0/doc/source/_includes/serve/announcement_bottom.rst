.. image:: https://ray-docs-promo.netlify.app/assets/img/serve/bottom.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/serve
