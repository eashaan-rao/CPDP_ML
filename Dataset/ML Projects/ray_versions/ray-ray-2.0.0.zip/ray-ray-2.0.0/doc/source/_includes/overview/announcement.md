```{image} https://ray-docs-promo.netlify.app/assets/img/overview/top.png
:alt: true
:target: https://ray-docs-promo.netlify.app/overview
```

```{eval-rst}
.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/overview/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/overview
```
