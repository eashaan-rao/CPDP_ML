.. image:: https://ray-docs-promo.netlify.app/assets/img/train/top.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/train

.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/train/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/train
