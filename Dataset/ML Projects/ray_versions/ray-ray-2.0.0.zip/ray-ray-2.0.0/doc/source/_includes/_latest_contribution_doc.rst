.. admonition:: Check your version!

    Things can change quickly, and so does this contributor guide.
    To make sure you've got the most cutting edge version of this guide,
    go check out the
    `latest version <https://docs.ray.io/en/master/ray-contribute/getting-involved.html>`__.
