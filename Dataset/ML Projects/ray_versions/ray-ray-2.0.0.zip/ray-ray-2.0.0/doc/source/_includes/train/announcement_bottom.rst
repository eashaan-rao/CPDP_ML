.. image:: https://ray-docs-promo.netlify.app/assets/img/train/bottom.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/train
