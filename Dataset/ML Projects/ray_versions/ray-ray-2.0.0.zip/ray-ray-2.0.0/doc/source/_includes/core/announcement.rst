.. image:: https://ray-docs-promo.netlify.app/assets/img/core/top.png
    :alt:
    :target: https://ray-docs-promo.netlify.app/core

.. div:: bottom-right-promo-banner

    .. image:: https://ray-docs-promo.netlify.app/assets/img/core/square.png
        :alt:
        :target: https://ray-docs-promo.netlify.app/core
