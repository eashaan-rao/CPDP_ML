module.exports = {
  video: false,
  screenshotOnRunFailure: false,
  retries: {
    runMode: 2,
  },
  e2e: {
    setupNodeEvents(on, config) {},
  },
}
