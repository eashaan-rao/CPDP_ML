"""A file dependency for testing working_dir behavior with Ray Tune."""


def foo():
    pass
