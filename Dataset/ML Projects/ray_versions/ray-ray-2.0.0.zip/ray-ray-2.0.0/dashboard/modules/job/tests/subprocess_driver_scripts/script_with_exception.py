def run():
    raise Exception("Script failed with exception !")


if __name__ == "__main__":
    run()
