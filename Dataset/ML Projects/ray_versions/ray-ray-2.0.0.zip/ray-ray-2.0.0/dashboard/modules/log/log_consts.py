MIME_TYPES = {
    "text/plain": [".err", ".out", ".log"],
}

LOG_GRPC_ERROR = "log_grpc_status"
FILE_NOT_FOUND = "LOG_GRPC_ERROR: file_not_found"

# 10 seconds
GRPC_TIMEOUT = 10
