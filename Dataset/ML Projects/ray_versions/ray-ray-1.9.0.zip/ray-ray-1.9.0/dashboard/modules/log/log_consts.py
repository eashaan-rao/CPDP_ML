MIME_TYPES = {
    "text/plain": [".err", ".out", ".log"],
}
