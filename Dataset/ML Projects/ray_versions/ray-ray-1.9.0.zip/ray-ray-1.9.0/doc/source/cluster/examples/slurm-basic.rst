:orphan:

.. _slurm-basic:

slurm-basic.sh
~~~~~~~~~~~~~~

.. literalinclude:: /cluster/examples/slurm-basic.sh
