:orphan:

.. _slurm-template:

slurm-template.sh
~~~~~~~~~~~~~~~~~

.. literalinclude:: /cluster/examples/slurm-template.sh
    :language: bash
