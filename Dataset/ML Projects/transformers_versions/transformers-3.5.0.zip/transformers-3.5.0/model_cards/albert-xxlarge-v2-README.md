---
tags:
- exbert

license: apache-2.0
---

<a href="https://huggingface.co/exbert/?model=albert-xxlarge-v2">
	<img width="300px" src="https://cdn-media.huggingface.co/exbert/button.png">
</a>