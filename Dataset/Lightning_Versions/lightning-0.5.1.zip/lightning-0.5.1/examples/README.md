# Examples   
This folder has 3 sections:   

### Domain templates   
These are templates to show common approaches such as GANs and RL.   

### Basic examples   
These show the most common use of Lightning for either CPU or GPU training.   

### Multi-node examples   
These show how to run jobs on a GPU cluster using lightning.