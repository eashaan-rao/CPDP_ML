from .basic_examples.lightning_module_template import LightningTemplateModel

__all__ = [
    'LightningTemplateModel'
]
