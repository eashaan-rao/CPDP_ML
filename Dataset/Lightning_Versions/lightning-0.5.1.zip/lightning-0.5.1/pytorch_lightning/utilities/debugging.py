class MisconfigurationException(Exception):
    pass
