Shared neural network models for RLlib.
