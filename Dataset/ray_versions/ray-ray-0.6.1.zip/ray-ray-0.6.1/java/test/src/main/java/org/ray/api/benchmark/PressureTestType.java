package org.ray.api.benchmark;

public enum PressureTestType {

  SINGLE_LATENCY,
  RATE_LIMITER,
  MAX
}
