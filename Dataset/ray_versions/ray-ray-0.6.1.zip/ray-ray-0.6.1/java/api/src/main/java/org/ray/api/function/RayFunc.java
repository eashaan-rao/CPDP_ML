package org.ray.api.function;

import java.io.Serializable;

/**
 * Interface of all Ray remote functions.
 */
public interface RayFunc extends Serializable {

}
