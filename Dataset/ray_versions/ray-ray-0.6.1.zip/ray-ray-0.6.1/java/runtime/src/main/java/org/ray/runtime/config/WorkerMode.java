package org.ray.runtime.config;

public enum WorkerMode {
  DRIVER,
  WORKER
}
