package org.ray.cli;

import com.beust.jcommander.Parameters;

/**
 * Arguments for command stop.
 */
@Parameters(separators = "= ", commandDescription = "stop ray daemons")
public class CommandStop {

}
