Pandas on Ray
=============

**Pandas on Ray has moved to Modin!**

Pandas on Ray has moved into the `Modin project`_ with the intention of
unifying the DataFrame APIs.

.. _`Modin project`: https://github.com/modin-project/modin
