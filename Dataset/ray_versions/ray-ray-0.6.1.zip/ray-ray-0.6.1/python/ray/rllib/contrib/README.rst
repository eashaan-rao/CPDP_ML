Contributed algorithms, which can be run via ``rllib train --run=contrib/<alg_name>``

See https://ray.readthedocs.io/en/latest/rllib-dev.html for guidelines.
