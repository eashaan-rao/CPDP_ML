Code in this package is adapted from https://github.com/oxwhirl/pymarl_alpha.
