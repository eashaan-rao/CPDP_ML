Transformer XL
----------------------------------------------------


``TransfoXLConfig``
~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TransfoXLConfig
    :members:


``TransfoXLTokenizer``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TransfoXLTokenizer
    :members:


``TransfoXLModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TransfoXLModel
    :members:


``TransfoXLLMHeadModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: transformers.TransfoXLLMHeadModel
    :members:


``TFTransfoXLModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TFTransfoXLModel
    :members:


``TFTransfoXLLMHeadModel``
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autoclass:: pytorch_transformers.TFTransfoXLLMHeadModel
    :members:
