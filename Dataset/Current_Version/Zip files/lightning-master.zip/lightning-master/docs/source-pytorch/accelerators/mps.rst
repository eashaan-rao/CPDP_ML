.. _mps:

Accelerator: Apple Silicon training
===================================

.. raw:: html

    <div class="display-card-container">
        <div class="row">

.. Add callout items below this line

.. displayitem::
   :header: Prepare your code (Optional)
   :description: Prepare your code to run on any hardware
   :col_css: col-md-4
   :button_link: accelerator_prepare.html
   :height: 150
   :tag: basic

.. displayitem::
   :header: Basic
   :description: Learn the basics of Apple silicon gpu training.
   :col_css: col-md-4
   :button_link: mps_basic.html
   :height: 150
   :tag: basic

.. raw:: html

        </div>
    </div>
