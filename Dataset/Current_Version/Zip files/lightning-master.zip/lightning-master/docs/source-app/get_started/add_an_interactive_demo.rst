:orphan:

#######################
Add an Interactive Demo
#######################

.. _add_an_interactive_Demo:

**Required background:** Basic Python familiarity and complete the install guide.

**Goal:** We'll walk you through the 4 key steps to run a Lightning App that trains and demos a model.

----

.. include:: go_beyond_training_content.rst
