##########################
Level 17: Rerun components
##########################
**Audience:** Users who want Work.run() to activate multiple times in an app.

**Prereqs:** Level 16+ and read the :doc:`Event Loop guide <../../glossary/event_loop>`.

----

.. include:: ../../workflows/run_work_once_content.rst
