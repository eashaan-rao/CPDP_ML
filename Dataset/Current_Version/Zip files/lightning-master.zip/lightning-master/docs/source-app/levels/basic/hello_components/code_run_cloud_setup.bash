lightning run app app.py --setup --cloud
