:orphan:

##########################################
Communication between Lightning Components
##########################################

**Audience:** Users that want to create interactive applications.

**Level:** Intermediate

**Prerequisite**: Read the :doc:`Communication in Lightning Apps article <../../../workflows/access_app_state>`.

----

.. include:: ../../core_api/lightning_app/communication_content.rst
