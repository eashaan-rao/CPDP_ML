``jax.dlpack`` module
=====================

.. currentmodule:: jax.dlpack

.. automodule:: jax.dlpack

.. autosummary::
    :toctree: _autosummary

    from_dlpack
    to_dlpack