# Profiling and performance

```{note}
This is a placeholder for a section in the new {ref}`jax-tutorials`.

For the time being, you may find some related content in the old documentation:
- {doc}`../profiling`
- {doc}`../device_memory_profiling`
- {doc}`../transfer_guard`
```
