# Example: Writing a simple neural network

```{note}
This is a placeholder for a section in the new {ref}`jax-tutorials`.
```
