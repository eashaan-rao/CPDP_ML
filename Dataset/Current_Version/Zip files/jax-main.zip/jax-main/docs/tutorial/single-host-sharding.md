# Sharded data on a single host

```{note}
This is a placeholder for a section in the new {ref}`jax-tutorials`.
```
