# Just-in-time compilation

```{note}
This is a placeholder for a section in the new {ref}`jax-tutorials`.

For the time being, you may find some related content in the old documentation:
- {doc}`../jax-101/02-jitting`
```