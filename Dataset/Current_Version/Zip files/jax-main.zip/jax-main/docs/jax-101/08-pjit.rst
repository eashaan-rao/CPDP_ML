:orphan:

Introduction to `pjit`
======================

This content is no longer relevant, because :func:`~jax.pjit` and :func:`~jax.jit`
have been merged into a single unified interface.
For an updated guide to compiling and executing JAX functions in multi-host or multi-core environments,
see :doc:`../notebooks/Distributed_arrays_and_automatic_parallelization`.
