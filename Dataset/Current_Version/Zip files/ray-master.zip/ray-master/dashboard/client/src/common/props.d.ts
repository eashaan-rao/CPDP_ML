export type ClassNameProps = {
  className?: string;
};
